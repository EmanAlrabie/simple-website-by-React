import React, {useState} from 'react';
import './App.css';
import Users from './pages/Users';
import Home from './pages/Home';
import { Router, Route, Switch, Link } from 'react-router-dom';
import { createBrowserHistory } from "history";
import Courses from './components/Courses'
import AddUser from './components/AddUser';
import HeaderSection from './components/HeaderSection'

export const ThemeContext = React.createContext();

export default function App() {
  const history = createBrowserHistory()

  const [userName, setUserName] = useState('Eman')
  return (
    <div className='App'>

      <ThemeContext.Provider value={userName}>
        <Router history={history}>
          <Home />

          <Switch>
          <Route exact path={'/'} component={HeaderSection} />
            <Route exact path={'/lecturer'} component={Users} />
            <Route exact path={'/courses'} component={Courses} />
            <Route exact path={'/log-in'} component={AddUser} />


          </Switch>
        </Router>
      </ThemeContext.Provider>
    </div>
  );
}


