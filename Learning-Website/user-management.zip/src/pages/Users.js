import React, { Fragment, useState, useEffect } from 'react';
import UserData from '../components/UserData.js'
import AddUser from '../components/AddUser.js'
import './Users.css'
import { Skeleton, Switch, Card, Avatar } from 'antd';
import { EditOutlined, EllipsisOutlined, SettingOutlined } from '@ant-design/icons';
import { Button, Radio } from 'antd';
import { Link } from 'react-router-dom';
import { useLocation,useParams,useHistory } from 'react-router-dom';
import axios from 'axios';
//class based component
// export default class users extends Component {

//     state={
//         numberOfUsers:2,
//         userInfo:{
//             name:'Eman',
//             age: 24,
//         },
//         user2Info:{
//             name:'Sara',
//             age: 21,
//         }
//     }

//     changeUserInfo(data){
//         this.setState({
//             ...this.state,
//             userInfo: data
//         })
//     }
//     componentDidMount(){
//         setTimeout(() => {
//             alert('Welcome to XXXX website')
//         }, 1000);

//     }
//     componentDidUpdate(){
//              alert('your info update successfully')
//          }

//     componentWillUnmount(){
//             alert('The code changed')
//     }

//     render() {
//         return (
//             <div className='users'>
//                 <div className='userItems'>
//                 <UserImage />
//                 <UserData userInfo={this.state.userInfo} changeUserInfo={this.changeUserInfo.bind(this)}/>
//                 </div>

//             </div>
//         )
//     }
// }


//functional based component 

export default function Users() {
    // 
    // const location = useLocation(); //get url path
    // const { id } = useParams(); // get parameters in url path
    // const { push } = useHistory(); // History of url

    const { Meta } = Card;
    const [loading, setLoading] = useState(true)

    const [size, setSize] = useState('large')

    const handleSizeChange = (e) => {
        setSize(e.target.value)
    }

    const onChange = (checked) => {
        setLoading(!checked)
    }
    const [numberOfUsers, setNumberOfUsers] = useState(3);
    //Wayes to stor data: 1- in state in the component
    // const [userInfo, setuserInfo] =
    //     useState([{
    //         name: 'Eman',
    //         age: 24,
    //         image: "https://joeschmoe.io/api/v1/jess"
    //     },
    //     {
    //         name: 'Sara',
    //         age: 15,
    //         image: 'https://joeschmoe.io/api/v1/julie'
    //     },
    //     {
    //         name: 'Mona',
    //         age: 30,
    //         image: 'https://joeschmoe.io/api/v1/jeri'
    //     }]);

    const changeUserInfo = (data) => {
        setuserInfo(data)
    }
    const addUser = (newUser) => {
        setuserInfo([
            ...userInfo,
            newUser
        ])
    }


 //2- store in jeson file
 const [userInfo, setuserInfo] =useState([])

     //    call api with axios laibrary
    // axios.get  // type getting data 
    // axios.post //  type to post data 
    // axios.put  // type for updating
    // axios.delete // type to delete record 
    useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
    .then((response)=>{
        setuserInfo(response.data)
    })
    .catch((error)=>{
        console.log('error',error)

    })
    }, [])

    // //componentDidMount
    // useEffect(()=>{
    //     alert('Welcome to XXXX website')
    // },[]);

    // //componentDidUpdate
    // useEffect(()=>{
    //   if(userInfo.name == 'Eman'){
    //       return
    //   }
    //   else{
    //     alert('your info update successfully')
    //   }

    // });

    // // componentWillUnmount
    // useEffect(()=>{
    //     return(
    //         alert('Unmount')
    //     )

    // }, []);

    return (
        <Fragment>


            <>
                {userInfo.length > 0 ?
                    userInfo.map((user) => {
                        return (
                            <Fragment>
                                <Card style={{ width: 300, marginTop: 16 }} loading={false}>
                                    <Meta
                                        avatar={<Avatar src='https://toppng.com/public/uploads/thumbnail/roger-berry-avatar-placeholder-115629915618zfpmweri9.png' />}
                                        title={user.name}
                                        description={user.email + '' }
                                        
                                    />
                                </Card>
                            </Fragment>
                        )

                    })
                    : <p>No active user</p>}
                <br />
                <Link to='/add-user'>
                    <Radio.Group value={size} onChange={handleSizeChange} >
                        <Radio.Button value="large">Add user</Radio.Button>
                    </Radio.Group>
                </Link>

                {/* <AddUser addUser={addUser}/> */}

            </>




            {/* <div className='users'>
                
                <div className='userItems'>
                    <h1>
                        {numberOfUsers} 
                        active users
                    </h1>
                    <br />
                    <button type="button" class="btn btn-info"
                        onClick={() => {
                            setNumberOfUsers(numberOfUsers + 1)
                        }}>increment number of users</button>
                    <br />
                    <br />
                    {
                        userInfo.length > 0 ?
                            userInfo.map((user) => {
                                return (
                                    <Fragment>
                                        <UserImage />
                                        <UserData userInfo={user} changeUserInfo={changeUserInfo} />
                                    </Fragment>
                                )

                            })
                            : <p>No active user</p>

           }
                </div>
            </div> */}
        </Fragment>
    )
}

