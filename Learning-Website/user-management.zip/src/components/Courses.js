import React, { Fragment } from 'react'
import { Card } from 'semantic-ui-react'

const items = [
    {
        header: 'ReactJs ',
        description:
            'Learn the essentials of React JS programming to advance your skills in the lucrative field of web development.',
        meta: '24-28/10',
    },
    {
        header: 'Node JS',
        description:
            'Learning Node.js is a great way to get into backend web development, or expand your fullstack development practice. With Udemy’s hands-on Node.js courses, you can learn the concepts and applications of this wildly useful JavaScript runtime.',
        meta: '15-20/11',
    },
    {
        header: 'Angular',
        description:
            'Angular is one of the most popular frameworks for building client apps with HTML, CSS and TypeScript. If you want to establish yourself as a front-end or a full-stack developer, you need to learn Angular.',
        meta: '1-10/12',
    },
]

const CardExampleGroupProps = () => {
    return (
        <Fragment>
            <h2>Our Courses</h2>
            <Card.Group items={items} />
        </Fragment>

    )

}
export default CardExampleGroupProps