import React from 'react'
import { Row, Col } from 'antd';
import { Image } from 'semantic-ui-react'
import HearerImage from '../images/onlineStudy.png'
import './HeaderSection.css'
import { Button, Radio } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';


export default function HeaderSection() {
    return (
        <div>
            <Row>

                <Col className='header-title' lg={14} md={14} sm={24} xs={24}>Hello And Welcome Here!<br />
                    <p className='header-content'>Here you can learn new and most programming languages for free! </p>
                    <br /> <Button className='header-button' shape="round" size='large'>
                     <Link to='/log-in'>Get Start </Link>   
                    </Button>
                </Col>
                <Col className='header-image' lg={10} md={10} sm={24} xs={24}>  <Image src={HearerImage} size='large' rounded />
                </Col>
            </Row>

        </div>
    )
}
