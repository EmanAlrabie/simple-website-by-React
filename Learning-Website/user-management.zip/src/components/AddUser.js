// import { Form, Input, Button, Checkbox } from 'antd';
// import { Link } from 'react-router-dom';
// import { Upload, message } from 'antd';
// import './AddUser.css'

// const AddUser = (props) => {


//     const onFinish = (values) => {
//         console.log('Success:', values);
//         props.addUser(values)
//     };

//     const onFinishFailed = (errorInfo) => {
//         console.log('Failed:', errorInfo);
//     };
//     const pr = {
//         name: 'file',
//         action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
//         headers: {
//             authorization: 'authorization-text',
//         },
//         onChange(info) {
//             if (info.file.status !== 'uploading') {
//                 console.log(info.file, info.fileList);
//             }
//             if (info.file.status === 'done') {
//                 message.success(`${info.file.name} file uploaded successfully`);
//             } else if (info.file.status === 'error') {
//                 message.error(`${info.file.name} file upload failed.`);
//             }
//         },
//     };

//     return (
//         <Form style={{ textAlign: 'center',color:'primary', marginTop: 48, marginBottom: 40 }}
//         className='form-log-in'
//             name="basic"
//             labelCol={{ span: 8 }}
//             wrapperCol={{ span: 10 }}
//             initialValues={{ remember: true }}
//             onFinish={onFinish}
//             onFinishFailed={onFinishFailed}
//             autoComplete="off"
//         >
//             <Form.Item
//                 label="Username"
//                 name="username"
//                 rules={[{ required: true, message: 'Please input your username!' }]}
//             >
//                 <Input />
//             </Form.Item>

//             <Form.Item
//                 label="Password"
//                 name="password"
//                 rules={[{ required: true, message: 'Please input your password!' }]}
//             >
//                 <Input.Password />
//             </Form.Item>

//             <Form.Item name="remember" valuePropName="checked" wrapperCol={{ offset: 8, span: 16 }}>
//                 <Checkbox>Remember me</Checkbox>
//             </Form.Item>

//             <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
//                 <Button type="primary" htmlType="submit">
//                     Submit
//                 </Button>
//             </Form.Item>
//         </Form>
//     );
// };


// export default AddUser;

import React, {Component} from 'react'
import { Button, Form, Segment } from 'semantic-ui-react'
import { Link } from 'react-router-dom'

export default class LogIN extends Component {
    state = { name: '', email: '', submittedName: '', submittedEmail: '' }

    handleChange = (e, { name, value }) => this.setState({ [name]: value })

    handleSubmit = () => {
        const { name, email } = this.state

        this.setState({ submittedName: name, submittedEmail: email })
    }

    render() {
        const { name, email, submittedName, submittedEmail } = this.state

        return (
            <Segment inverted>
                <Form inverted onSubmit={this.handleSubmit} >
                    <Form.Group widths='equal'>
                        <Form.Input required fluid label='Username' placeholder='Username' onChange={this.handleChange}/> 
                        <Form.Input required type='password' fluid label='Password' placeholder='Enter Password' />
                    </Form.Group>
                    <Form.Checkbox label='I agree to the Terms and Conditions' />
                    <Button as={Link} to='/courses' type='submit'>Submit</Button>
                </Form>
            </Segment>
        )
        }
    }
